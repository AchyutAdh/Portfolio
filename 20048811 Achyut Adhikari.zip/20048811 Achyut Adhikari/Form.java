import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
public class Form{
    public static void main(String args[]){
        JFrame frame = new JFrame("Form1"); //creating the frame
        JPanel window = new JPanel(); // creating the panel
        
        // creating widgets
        JLabel top = new JLabel("Student Registration Form");
        
        
        JLabel id = new JLabel("Student ID:");
        JTextField text1 = new JTextField();
        
        
        JLabel schoolyear = new JLabel("School Year:");
        String[] syear = {"2014-2015","2015-2016","2016-2017","2017-2018","2018-2019","2019-2020","2020-2021"};
        JComboBox combo1 = new JComboBox(syear);
        
        
        JLabel fname = new JLabel("First Name:");
        JTextField text2 = new JTextField();
        
        
        
        JLabel lname = new JLabel("Last Name:");
        JTextField text3 = new JTextField();
        
        JLabel mname = new JLabel("Middle Name:");
        JTextField text4 = new JTextField();
        
        JLabel address = new JLabel("Address:");
        JTextArea area1 = new JTextArea();
        
        JLabel dob = new JLabel("Date of Birth:");
        String[] year = {"1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004","2005", "2006", "2007"};
        String[] month = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        String[] day = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"};
        JComboBox combo2 = new JComboBox(year);
        JComboBox combo3 = new JComboBox(month);
        JComboBox combo4 = new JComboBox(day);
        
        
        
        JLabel pob = new JLabel("Place of Birth:");
        JTextArea area2 = new JTextArea();
        
        JLabel age = new JLabel("Age:");
        JTextField text5 = new JTextField();
        
        JLabel gender = new JLabel("Gender:");
        JRadioButton radio1 = new JRadioButton();
        radio1.setText("Male");
        JRadioButton radio2 = new JRadioButton();
        radio2.setText("Female");
        ButtonGroup group1 = new ButtonGroup();
        group1.add(radio1);
        group1.add(radio2);
        
        
        JLabel status = new JLabel("Status:");
        String[] stat = {"Single","Married"};
        JComboBox combo5 = new JComboBox(stat);
        
        JLabel year1 = new JLabel("Year:");
        String[] ayear = {"1st","2nd","3rd","4th"};
        JComboBox combo6 = new JComboBox(ayear);
        
        JLabel guardian = new JLabel("Guardian:");
        JTextField text6 = new JTextField();
        
        JLabel relation = new JLabel("Relation:");
        JTextField text7 = new JTextField();
        
        JLabel address1 = new JLabel("Address:");
        JTextArea area3= new JTextArea();
        
        JLabel contact = new JLabel("Contact#:");
        JTextField text8 = new JTextField();
        
        JButton button1 = new JButton("|<");
        JButton button2 = new JButton("<<");
        JButton button3 = new JButton(">>");
        JButton button4 = new JButton(">|");
        
        JLabel page = new JLabel("0 of 0");
        
        JButton button5 = new JButton("New");
        JButton button6 = new JButton("Save");
        
        
        //adding the widgets
        window.add(top);
        window.add(id);
        window.add(text1);
        window.add(schoolyear);
        window.add(combo1);
        window.add(fname);
        window.add(text2);
        window.add(lname);
        window.add(mname);
        window.add(text3);
        window.add(text4);
        window.add(address);
        window.add(area1);
        window.add(dob);
        window.add(combo2);
        window.add(combo3);
        window.add(combo4);
        window.add(pob);
        window.add(area2);
        window.add(age);
        window.add(text5);
        window.add(gender);
        window.add(radio1);
        window.add(radio2);
        window.add(status);
        window.add(combo5);
        window.add(year1);
        window.add(combo6);
        window.add(guardian);
        window.add(text6);
        window.add(relation);
        window.add(text7);
        window.add(address1);
        window.add(contact);
        window.add(area3);
        window.add(text8);
        window.add(button1);
        window.add(button2);
        window.add(button3);
        window.add(button4);
        window.add(page);
        window.add(button5);
        window.add(button6);
        
        // positioning the widgets
        top.setFont(new Font ("Bahnschrift",Font.BOLD, 20));
        top.setBounds(240, 20, 300, 40);
        
        id.setBounds(20, 80, 80, 20);
        text1.setBounds(100, 78, 85, 25);
        
        schoolyear.setBounds(535, 80, 80, 20);
        combo1.setBounds(630, 78, 120, 25);
        
        fname.setBounds(20, 120, 80, 20);
        text2.setBounds(100, 118, 120, 25);
        
        lname.setBounds(250, 120, 80, 20);
        text3.setBounds(320, 118, 190, 25);
        
        mname.setBounds(530, 120, 80, 20);
        text4.setBounds(630, 118, 120, 25);
        
        address.setBounds(34, 160, 60, 20);
        area1.setBounds(100, 158, 120, 40);
        
        dob.setBounds(236, 160, 80, 20);
        combo2.setBounds(315, 158, 60, 25);
        combo3.setBounds(385, 158, 80, 25);
        combo4.setBounds(475, 158, 40, 25);
        
        pob.setBounds(530, 160, 80, 20);
        area2.setBounds(630, 158, 120, 40);
        
        
        age.setBounds(60, 220, 40, 20);
        text5.setBounds(100, 220, 60, 20);
        
        gender.setBounds(265, 220, 50, 20);
        radio1.setBounds(330, 220, 70, 20);
        radio2.setBounds(410, 220, 80, 20);
        
        status.setBounds(570, 220, 40, 20);
        combo5.setBounds(630, 218, 120, 25);
        
        year1.setBounds(58, 260, 40, 20);
        combo6.setBounds(100, 258, 90, 25);
        
        guardian.setBounds(260, 260, 70, 20);
        text6.setBounds(320, 258, 170, 25);
        
        relation.setBounds(560, 260, 50, 20);
        text7.setBounds(630, 258, 120, 25);
        
        address1.setBounds(34, 300, 60, 20);
        area3.setBounds(100, 298, 220, 60);
        
        contact.setBounds(435, 300, 60, 20);
        text8.setBounds(515, 298, 236, 25);
        
        button1.setBounds(20, 400, 50, 25);
        button2.setBounds(80, 400, 50, 25);
        button3.setBounds(140, 400, 50, 25);
        button4.setBounds(200, 400, 50, 25);
        page.setBounds(270, 400, 35, 25);
        
        
        button5.setBounds(460, 390, 120, 30); 
        button6.setBounds(590, 390, 162, 30);
        
        
        window.setLayout(null);
        frame.add(window);
        window.setBounds(0, 0, 790, 500);
        
        
        
        frame.setSize(790, 500);
        frame.setLayout(null);
        frame.setVisible(true);
        
    }
}